$ErrorActionPreference = "Stop"

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDir) { $ScriptDir = Get-Location }

# 1. Get Absolute Path of manifest.xml in the SAME directory
$ManifestPath = Join-Path $ScriptDir "manifest.xml"
if (-not (Test-Path $ManifestPath)) {
    Write-Host "Error: Could not find manifest.xml in $ScriptDir" -ForegroundColor Red
    Write-Host "`nPress any key to exit..."
    $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | Out-Null
    exit 1
}

# 2. Extract Add-in ID from Manifest
try {
    [xml]$manifest = Get-Content $ManifestPath -Encoding UTF8
    $AddInId = $manifest.OfficeApp.Id
} catch {
    Write-Host "Error: Could not parse manifest.xml - $_" -ForegroundColor Red
    Write-Host "`nPress any key to exit..."
    $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | Out-Null
    exit 1
}

if (-not $AddInId) {
    Write-Host "Error: Could not extract Add-in ID from manifest.xml" -ForegroundColor Red
    Write-Host "`nPress any key to exit..."
    $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | Out-Null
    exit 1
}

Write-Host "----------------------------------------"
Write-Host "Word Add-in Registry Installer"
Write-Host "----------------------------------------"
Write-Host "Add-in ID:     $AddInId"
Write-Host "Manifest Path: $ManifestPath"
Write-Host "----------------------------------------"

# 3. Target Office Versions
$Versions = @("15.0", "16.0", "17.0", "18.0", "19.0", "20.0")
$InstalledCount = 0

foreach ($Ver in $Versions) {
    $BasePath = "HKCU:\Software\Microsoft\Office\$Ver"
    if (Test-Path $BasePath) {
        try {
            $WefPath = "$BasePath\Wef"
            $DevPath = "$WefPath\Developer"
            
            if (-not (Test-Path $WefPath)) { New-Item -Path $WefPath -Force | Out-Null }
            if (-not (Test-Path $DevPath)) { New-Item -Path $DevPath -Force | Out-Null }
            
            # Set manifest path (String value)
            New-ItemProperty -Path $DevPath -Name $AddInId -Value $ManifestPath -PropertyType String -Force | Out-Null
            
            # Set debugger options (DWORD values)
            New-ItemProperty -Path $DevPath -Name "UseDirectDebugger" -Value 1 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $DevPath -Name "OpenDevToolsOnLoad" -Value 1 -PropertyType DWord -Force | Out-Null
            
            Write-Host "Successfully registered for Office $Ver" -ForegroundColor Green
            $InstalledCount++
        } catch {
            Write-Host "Warning: Failed to register for Office $Ver - $_" -ForegroundColor Yellow
        }
    }
}

if ($InstalledCount -eq 0) {
    Write-Host "`nWarning: No Office installation registry keys found (15.0-20.0)." -ForegroundColor Yellow
} else {
    Write-Host "`nInstallation Complete! Please restart Word." -ForegroundColor Cyan
}

Write-Host "`nPress any key to exit..."
$Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | Out-Null
